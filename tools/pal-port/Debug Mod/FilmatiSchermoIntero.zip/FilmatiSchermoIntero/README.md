<!--
  Filmati a schermo intero - README
  Author: https://github.com/Leproide
  License: GPL-3.0-or-later
-->

# Filmati a schermo intero (prova)

Durante i filmati mostra solo l area del video (320x176) e la adatta alla finestra senza deformarla, invece di mostrarla piccola dentro il riquadro 4:3. Si attiva e disattiva dal pannello della mod. Solo MediEvil PAL italiano.

## Licenza

GPL-3.0-or-later.

## Autore

https://github.com/Leproide
