// SPDX-License-Identifier: GPL-3.0-or-later
//
// Correzione dialoghi XA - mod di prova per MediEvilRecomp ITA
// Copyright (C) 2026
// Author: https://github.com/Leproide
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.

// Il primo discorso del gargoyle nella cripta si chiudeva subito.
//
// Le tracce audio XA del gioco (musica e voci) finiscono con un settore dati
// "marcatore" (intestazione 0x0160) che indica il canale terminato. Il callback dati
// del gioco (func_8006D7A4) lo confronta con il canale della traccia corrente
// ($gp+0x6C4) e, se coincide, segnala "traccia finita" e il discorso viene chiuso.
//
// Quando parte un discorso mentre suona la musica del livello, il gioco prima sceglie
// il nuovo canale (func_8006D0D8) e solo dopo un po' sposta la lettura sul file
// della voce (ReadS). In quell'intervallo RecompOne continua a consegnare i settori
// della musica: un marcatore di fine con lo stesso numero di canale viene preso per
// la fine del discorso, che si chiude dopo un attimo.
//
// Correzione: tra la scelta di una nuova traccia e il comando di lettura che la avvia,
// il controllo del marcatore viene saltato.

using System;
using ImGuiNET;
using RecompOne.Runtime.Context;
using RecompOne.Runtime.Memory;
using RecompOne.Runtime.Modding;

public class CorrezioneDialoghiMod : IMod
{
    const byte CdlReadN = 0x06, CdlReadS = 0x1B;

    static volatile bool _pending;   // nuova traccia scelta, lettura non ancora avviata
    static int _ignored;

    public void OnLoad() { }
    public void OnUnload() => _pending = false;

    public void DrawSettings()
    {
        ImGui.TextWrapped("Ignora i marcatori di fine traccia XA arrivati prima che la nuova traccia sia partita.");
        ImGui.TextDisabled($"Marcatori ignorati: {_ignored}");
    }

    // scelta di file/canale della nuova traccia XA
    [PostHook("game", Address = 0x8006D0D8u)]
    public static void TrackSelected(CpuContext c, IMemory m) => _pending = true;

    // un comando di lettura avvia la nuova traccia
    static void OnCommand(CpuContext c)
    {
        byte com = (byte)c.A0;
        if (com == CdlReadS || com == CdlReadN) _pending = false;
    }

    [PreHook("game", Address = 0x800AB124u)] public static void CdControl(CpuContext c, IMemory m) => OnCommand(c);
    [PreHook("game", Address = 0x800AB260u)] public static void CdControlF(CpuContext c, IMemory m) => OnCommand(c);
    [PreHook("game", Address = 0x800AB394u)] public static void CdControlB(CpuContext c, IMemory m) => OnCommand(c);

    // callback dati del lettore XA: salta il controllo del marcatore se la traccia non e' ancora partita
    [PreHook("game", Address = 0x8006D7A4u)]
    public static bool DataCallback(CpuContext c, IMemory m)
    {
        if (!_pending) return true;
        if (m.ReadU16(0x800F0CCCu) == 0x0160) _ignored++;
        return false;
    }
}
