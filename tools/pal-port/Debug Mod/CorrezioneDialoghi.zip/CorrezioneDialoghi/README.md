<!--
  Correzione dialoghi XA - README
  Author: https://github.com/Leproide
  License: GPL-3.0-or-later
-->

# Correzione dialoghi XA (prova)

Evita che un discorso si chiuda da solo, come il primo del gargoyle nella cripta. Quando un discorso parte mentre suona la musica, un marcatore di fine traccia della musica veniva scambiato per la fine del discorso. La mod ignora quei marcatori finche la nuova traccia non e partita. Solo MediEvil PAL italiano.

## Licenza

GPL-3.0-or-later.

## Autore

https://github.com/Leproide
