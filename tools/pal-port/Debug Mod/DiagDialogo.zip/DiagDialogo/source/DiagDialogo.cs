// SPDX-License-Identifier: GPL-3.0-or-later
//
// DiagDialogo - mod diagnostica per MediEvilRecomp ITA
// Copyright (C) 2026
// Author: https://github.com/Leproide
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.

// Diagnostica temporanea: il primo discorso del gargoyle nella cripta si chiude da solo.
// Registra, fotogramma per fotogramma quando cambiano:
//  - lo stato del pad letto dal gioco (blocco a 0x800F1B80);
//  - le variabili del lettore audio XA del gioco ($gp+0x6BC..0x700);
// e ogni chiamata a: riproduzione/stop XA, CdControl/CdControlF/CdControlB, overlay caricati.
// Scrive diag-dialogo.txt nella cartella del gioco (massimo 6000 righe).

using System;
using System.Diagnostics;
using System.IO;
using System.Text;
using ImGuiNET;
using RecompOne.Runtime.Context;
using RecompOne.Runtime.Memory;
using RecompOne.Runtime.Modding;

public class DiagDialogoMod : IMod
{
    const uint Gp = 0x800ED848u;          // $gp della versione PAL
    const uint PadBlock = 0x800F1B80u;    // stato del pad usato dal gioco
    static readonly object Gate = new();
    static readonly Stopwatch Clock = Stopwatch.StartNew();
    static StreamWriter? _out;
    static int _lines;
    const int MaxLines = 6000;
    static string _lastPad = "", _lastXa = "";
    static long _frame;

    public void OnLoad()
    {
        try
        {
            var path = Path.GetFullPath("diag-dialogo.txt");
            _out = new StreamWriter(path, false, new UTF8Encoding(false)) { AutoFlush = true };
            Write($"[DiagDialogo] log in {path}");
        }
        catch (Exception e) { Console.WriteLine($"[DiagDialogo] impossibile creare il file: {e.Message}"); }
    }

    public void OnUnload() { lock (Gate) { _out?.Dispose(); _out = null; } }

    public void DrawSettings()
    {
        ImGui.TextWrapped("Nuova partita, entra nella cripta, aspetta il primo discorso del gargoyle, poi chiudi il gioco e manda diag-dialogo.txt.");
        ImGui.TextDisabled($"Righe scritte: {_lines}/{MaxLines}");
    }

    static void Write(string s)
    {
        lock (Gate)
        {
            if (_lines >= MaxLines) return;
            _lines++;
            _out?.WriteLine(s);
        }
    }

    static string T => $"{Clock.ElapsedMilliseconds / 1000.0:0.000} f{_frame}";

    // ogni VSync: registra pad e stato XA solo quando cambiano
    [PostHook("game", Address = 0x800A3E18u)]
    public static void AfterVSync(CpuContext c, IMemory m)
    {
        _frame++;
        var sb = new StringBuilder();
        for (uint i = 0; i < 0x20; i += 4) sb.Append($"{m.ReadU32(PadBlock + i):X8} ");
        var pad = sb.ToString();
        if (pad != _lastPad)
        {
            _lastPad = pad;
            Write($"{T} PAD {pad}");
        }

        var xa = $"6bc={m.ReadU32(Gp + 0x6BC):X} 6d0={m.ReadU16(Gp + 0x6D0):X} 6d4={m.ReadU32(Gp + 0x6D4):X} 6d8={m.ReadU32(Gp + 0x6D8):X} " +
                 $"6dc={m.ReadU32(Gp + 0x6DC):X} 6e0={m.ReadU32(Gp + 0x6E0):X} 6e8={m.ReadU32(Gp + 0x6E8):X} 6fc={m.ReadU32(Gp + 0x6FC):X} " +
                 $"700={m.ReadU16(Gp + 0x700):X} mus={m.ReadU32(0x800EDA14u):X} cb={m.ReadU32(0x800EB660u):X}/{m.ReadU32(0x800EB664u):X}";
        if (xa != _lastXa)
        {
            _lastXa = xa;
            Write($"{T} XA {xa}");
        }
    }

    static void Call(string what, CpuContext c, IMemory m)
    {
        string p = "";
        if (c.A1 != 0 && (c.A1 & 0xFF000000u) == 0x80000000u)
            p = $" param={m.ReadU8(c.A1):X2} {m.ReadU8(c.A1 + 1):X2} {m.ReadU8(c.A1 + 2):X2} {m.ReadU8(c.A1 + 3):X2}";
        Write($"{T} {what} a0={c.A0:X8} a1={c.A1:X8} a2={c.A2:X8}{p} ra={c.RA:X8}");
    }

    [PreHook("game", Address = 0x8006DA8Cu)] public static void XaPlay(CpuContext c, IMemory m) => Call("XA traccia", c, m);
    [PreHook("game", Address = 0x8006D0D8u)] public static void XaFilter(CpuContext c, IMemory m) => Call("XA file/canale", c, m);
    [PreHook("game", Address = 0x8006D59Cu)] public static void XaStop(CpuContext c, IMemory m) => Call("XA stop", c, m);
    [PreHook("game", Address = 0x8006DA30u)] public static void XaDa30(CpuContext c, IMemory m) => Call("XA 8006DA30", c, m);
    [PreHook("game", Address = 0x8006D044u)] public static void XaD044(CpuContext c, IMemory m) => Call("XA 8006D044", c, m);
    [PreHook("game", Address = 0x8006D5E8u)] public static void XaD5E8(CpuContext c, IMemory m) => Call("XA 8006D5E8", c, m);
    [PreHook("game", Address = 0x8006D694u)] public static void XaD694(CpuContext c, IMemory m) => Call("XA 8006D694", c, m);
    [PreHook("game", Address = 0x800AB124u)] public static void CdControl(CpuContext c, IMemory m) => Call("CdControl", c, m);
    [PreHook("game", Address = 0x800AB260u)] public static void CdControlF(CpuContext c, IMemory m) => Call("CdControlF", c, m);
    [PreHook("game", Address = 0x800AB394u)] public static void CdControlB(CpuContext c, IMemory m) => Call("CdControlB", c, m);
}
