<!--
  DiagDialogo - README
  Author: https://github.com/Leproide
  License: GPL-3.0-or-later
-->

# Diagnostica dialoghi (temporanea)

Registra in `diag-dialogo.txt` lo stato del pad, i comandi al CD e il lettore audio XA, per capire perche il primo discorso del gargoyle nella cripta si chiude da solo. Non modifica il gioco. Da cancellare dopo l uso.

## Licenza

GPL-3.0-or-later.

## Autore

https://github.com/Leproide
