// SPDX-License-Identifier: GPL-3.0-or-later
//
// Correzione altezza video PAL - mod di prova per MediEvilRecomp ITA
// Copyright (C) 2026
// Author: https://github.com/Leproide
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.

// Ipotesi: PutDispEnv di RecompOne, quando DISPENV.screen.h vale 0 ("altezza
// predefinita"), usa 240 righe anche in modalita' PAL, dove dovrebbero essere 256.
// Il lettore dei filmati PAL mette il video (320x176) a y=40, centrato su 256 righe:
// con una finestra di 240 righe il filmato risulta spostato in basso e tagliato.
// La mod, solo per la durata di PutDispEnv, mette screen.h = 256 quando vale 0,
// e registra in console i valori di DISPENV quando cambiano.

using System;
using ImGuiNET;
using RecompOne.Runtime.Context;
using RecompOne.Runtime.Memory;
using RecompOne.Runtime.Modding;

public class CorrezioneVideoPALMod : IMod
{
    public static bool Fix = true;
    static uint _env;
    static bool _patched;
    static string _last = "";

    public void OnLoad() { }
    public void OnUnload() { }

    public void DrawSettings()
    {
        ImGui.Checkbox("Usa 256 righe quando l'altezza non e' indicata", ref Fix);
        ImGui.TextDisabled($"Ultimo DISPENV: {_last}");
    }

    static void Before(CpuContext c, IMemory m, string who)
    {
        uint env = c.A0;
        short dx = (short)m.ReadU16(env), dy = (short)m.ReadU16(env + 2);
        short dw = (short)m.ReadU16(env + 4), dh = (short)m.ReadU16(env + 6);
        short sx = (short)m.ReadU16(env + 8), sy = (short)m.ReadU16(env + 0xA);
        short sw = (short)m.ReadU16(env + 0xC), sh = (short)m.ReadU16(env + 0xE);
        var desc = $"{who} disp=({dx},{dy},{dw},{dh}) screen=({sx},{sy},{sw},{sh})";
        if (desc != _last)
        {
            _last = desc;
            Console.WriteLine($"[CorrezioneVideoPAL] {desc}");
        }

        _patched = false;
        if (Fix && sh == 0)
        {
            m.WriteU16(env + 0xE, 256);
            _env = env;
            _patched = true;
        }
    }

    static void After(IMemory m)
    {
        if (!_patched) return;
        m.WriteU16(_env + 0xE, 0);   // rimette il valore originale del gioco
        _patched = false;
    }

    // Registra la DRAWENV (area di disegno) quando cambia.
    static string _lastDraw = "";
    [PreHook("game", Address = 0x8009C8D0u)]
    public static void PreDrawEnv(CpuContext c, IMemory m)
    {
        uint e = c.A0;
        var d = $"clip=({(short)m.ReadU16(e)},{(short)m.ReadU16(e + 2)},{(short)m.ReadU16(e + 4)},{(short)m.ReadU16(e + 6)}) ofs=({(short)m.ReadU16(e + 8)},{(short)m.ReadU16(e + 0xA)})";
        if (d == _lastDraw) return;
        _lastDraw = d;
        Console.WriteLine($"[CorrezioneVideoPAL] DRAWENV {d}");
    }

    // Durante i filmati: rettangoli dove il lettore copia i fotogrammi e finestra mostrata dalla GPU.
    static int _movieLogs;
    [PostHook("game", Address = 0x80079D28u)]
    public static void AfterMovieFrame(CpuContext c, IMemory m)
    {
        if (_movieLogs++ % 50 != 0) return;
        var g = RecompOne.Runtime.Runtime.Gpu;
        string gpu = g == null ? "?" : $"vram=({g.DisplayX},{g.DisplayY}) {g.DisplayWidth}x{g.DisplayHeight}";
        Console.WriteLine($"[CorrezioneVideoPAL] FILMATO rett0=({(short)m.ReadU16(0x800F19D0u)},{(short)m.ReadU16(0x800F19D2u)},{(short)m.ReadU16(0x800F19D4u)},{(short)m.ReadU16(0x800F19D6u)}) " +
                          $"rett1=({(short)m.ReadU16(0x800F19F4u)},{(short)m.ReadU16(0x800F19F6u)},{(short)m.ReadU16(0x800F19F8u)},{(short)m.ReadU16(0x800F19FAu)}) GPU {gpu}");
    }

    [PreHook("game", Address = 0x8009C990u)]
    public static void PreGame(CpuContext c, IMemory m) => Before(c, m, "game");

    [PostHook("game", Address = 0x8009C990u)]
    public static void PostGame(CpuContext c, IMemory m) => After(m);

    [PreHook("main", Address = 0x801B2A8Cu)]
    public static void PreMain(CpuContext c, IMemory m) => Before(c, m, "main");

    [PostHook("main", Address = 0x801B2A8Cu)]
    public static void PostMain(CpuContext c, IMemory m) => After(m);
}
