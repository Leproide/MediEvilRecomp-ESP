<!--
  Correzione altezza video PAL - README
  Author: https://github.com/Leproide
  License: GPL-3.0-or-later
-->

# Correzione altezza video PAL (prova)

Quando il gioco non indica l altezza dello schermo, RecompOne usa 240 righe anche in PAL invece di 256: i filmati risultano spostati in basso. La mod usa 256 righe in quel caso e scrive in console i valori di DISPENV.

## Licenza

GPL-3.0-or-later.

## Autore

https://github.com/Leproide
