<!--
  DiagFade - README
  Author: https://github.com/Leproide
  License: GPL-3.0-or-later
-->

# Diagnostica dissolvenze (temporanea)

Registra in `diag-fade.txt` le funzioni del gioco che disegnano e i poligoni che producono, per trovare la dissolvenza che non copre gli angoli in widescreen. Non modifica il gioco. Da cancellare dopo l uso.

## Licenza

GPL-3.0-or-later.

## Autore

https://github.com/Leproide
