// SPDX-License-Identifier: GPL-3.0-or-later
//
// DiagFade - mod diagnostica per MediEvilRecomp ITA
// Copyright (C) 2026
// Author: https://github.com/Leproide
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.

// Diagnostica temporanea per la issue #7 (dissolvenza che non copre gli angoli in widescreen).
// Aggancia le funzioni del gioco che riservano pacchetti GPU nello scratchpad (0x1F800010),
// registra quali sono attive e decodifica i poligoni che producono (tipo, colore, vertici).
// Scrive diag-fade.txt nella cartella del gioco.

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using ImGuiNET;
using RecompOne.Runtime.Context;
using RecompOne.Runtime.Memory;
using RecompOne.Runtime.Modding;

public class DiagFadeMod : IMod
{
    const uint PacketPtr = 0x1F800010u;
    static readonly object Gate = new();
    static readonly Stopwatch Clock = Stopwatch.StartNew();
    static readonly Dictionary<uint, Stack<uint>> Starts = new();
    static readonly Dictionary<uint, (int Calls, long Bytes)> Stats = new();
    static readonly HashSet<uint> DumpedThisSecond = new();
    static long _lastDump;
    static StreamWriter? _out;
    static int _lines;
    const int MaxLines = 6000;

    public void OnLoad()
    {
        try
        {
            var path = Path.GetFullPath("diag-fade.txt");
            _out = new StreamWriter(path, false, new UTF8Encoding(false)) { AutoFlush = true };
            Write($"[DiagFade] log in {path}");
        }
        catch (Exception e) { Console.WriteLine($"[DiagFade] impossibile creare il file: {e.Message}"); }
    }

    public void OnUnload() { lock (Gate) { _out?.Dispose(); _out = null; } }

    public void DrawSettings()
    {
        ImGui.TextWrapped("Diagnostica dissolvenze: scrive diag-fade.txt. Fai comparire una dissolvenza " +
                          "(entra o esci da un livello) con il widescreen attivo, poi chiudi il gioco.");
        ImGui.TextDisabled($"Righe scritte: {_lines}/{MaxLines}");
    }

    static void Write(string s)
    {
        lock (Gate)
        {
            if (_lines >= MaxLines) return;
            _lines++;
            _out?.WriteLine(s);
        }
    }

    static string T => (Clock.ElapsedMilliseconds / 1000.0).ToString("0.000");

    static void Enter(uint fn, IMemory m)
    {
        lock (Gate)
        {
            if (!Starts.TryGetValue(fn, out var st)) Starts[fn] = st = new Stack<uint>();
            st.Push(m.ReadU32(PacketPtr));
        }
    }

    static void Leave(uint fn, CpuContext c, IMemory m)
    {
        uint start;
        lock (Gate)
        {
            if (!Starts.TryGetValue(fn, out var st) || st.Count == 0) return;
            start = st.Pop();
        }
        uint end = m.ReadU32(PacketPtr);
        long bytes = end >= start ? end - start : 0;
        lock (Gate)
        {
            Stats.TryGetValue(fn, out var s);
            Stats[fn] = (s.Calls + 1, s.Bytes + bytes);
        }

        // una decodifica per funzione al secondo
        bool dump;
        lock (Gate) dump = bytes > 0 && bytes < 0x4000 && DumpedThisSecond.Add(fn);
        if (dump) DumpPackets(fn, start, end, m);

        var t = Clock.ElapsedMilliseconds;
        if (t - _lastDump < 1000) return;
        _lastDump = t;
        string summary;
        lock (Gate)
        {
            summary = string.Join("  ", Stats.OrderBy(k => k.Key).Select(k => $"{k.Key:X8} x{k.Value.Calls} {k.Value.Bytes}B"));
            Stats.Clear();
            DumpedThisSecond.Clear();
        }
        Write($"{T} ATTIVE: {summary}");
    }

    // Decodifica i pacchetti GPU fra start ed end (formato PSX: tag + parole).
    static void DumpPackets(uint fn, uint start, uint end, IMemory m)
    {
        var sb = new StringBuilder();
        sb.Append($"{T} {fn:X8} pacchetti {start:X8}-{end:X8}:");
        uint a = start;
        int n = 0;
        while (a + 8 <= end && n < 24)
        {
            uint tag = m.ReadU32(a);
            int words = (int)(tag >> 24);
            if (words <= 0 || words > 16) { sb.Append($" [tag {tag:X8}?]"); break; }
            uint w1 = m.ReadU32(a + 4);
            byte cmd = (byte)(w1 >> 24);
            sb.Append($" |cmd {cmd:X2} col {w1 & 0xFFFFFF:X6}");
            if (cmd >= 0x20 && cmd < 0x40)
            {
                bool gour = (cmd & 0x10) != 0, tex = (cmd & 0x04) != 0, quad = (cmd & 0x08) != 0;
                int verts = quad ? 4 : 3;
                uint p = a + 8;
                for (int v = 0; v < verts; v++)
                {
                    if (gour && v > 0) p += 4;          // colore del vertice
                    uint xy = m.ReadU32(p);
                    sb.Append($" ({(short)(xy & 0xFFFF)},{(short)(xy >> 16)})");
                    p += 4;
                    if (tex) p += 4;                    // uv
                }
            }
            else
            {
                for (int k = 2; k <= words && k <= 4; k++) sb.Append($" {m.ReadU32(a + (uint)(k * 4)):X8}");
            }
            a += 4u + (uint)words * 4u;
            n++;
        }
        Write(sb.ToString());
    }

    [PreHook("game", Address = 0x80028A0Cu)] public static void P_80028A0C(CpuContext c, IMemory m) => Enter(0x80028A0Cu, m);
    [PostHook("game", Address = 0x80028A0Cu)] public static void Q_80028A0C(CpuContext c, IMemory m) => Leave(0x80028A0Cu, c, m);
    [PreHook("game", Address = 0x8002CC28u)] public static void P_8002CC28(CpuContext c, IMemory m) => Enter(0x8002CC28u, m);
    [PostHook("game", Address = 0x8002CC28u)] public static void Q_8002CC28(CpuContext c, IMemory m) => Leave(0x8002CC28u, c, m);
    [PreHook("game", Address = 0x8004EEE8u)] public static void P_8004EEE8(CpuContext c, IMemory m) => Enter(0x8004EEE8u, m);
    [PostHook("game", Address = 0x8004EEE8u)] public static void Q_8004EEE8(CpuContext c, IMemory m) => Leave(0x8004EEE8u, c, m);
    [PreHook("game", Address = 0x8004F358u)] public static void P_8004F358(CpuContext c, IMemory m) => Enter(0x8004F358u, m);
    [PostHook("game", Address = 0x8004F358u)] public static void Q_8004F358(CpuContext c, IMemory m) => Leave(0x8004F358u, c, m);
    [PreHook("game", Address = 0x8004F6E4u)] public static void P_8004F6E4(CpuContext c, IMemory m) => Enter(0x8004F6E4u, m);
    [PostHook("game", Address = 0x8004F6E4u)] public static void Q_8004F6E4(CpuContext c, IMemory m) => Leave(0x8004F6E4u, c, m);
    [PreHook("game", Address = 0x8004FE68u)] public static void P_8004FE68(CpuContext c, IMemory m) => Enter(0x8004FE68u, m);
    [PostHook("game", Address = 0x8004FE68u)] public static void Q_8004FE68(CpuContext c, IMemory m) => Leave(0x8004FE68u, c, m);
    [PreHook("game", Address = 0x80058E9Cu)] public static void P_80058E9C(CpuContext c, IMemory m) => Enter(0x80058E9Cu, m);
    [PostHook("game", Address = 0x80058E9Cu)] public static void Q_80058E9C(CpuContext c, IMemory m) => Leave(0x80058E9Cu, c, m);
    [PreHook("game", Address = 0x800659D4u)] public static void P_800659D4(CpuContext c, IMemory m) => Enter(0x800659D4u, m);
    [PostHook("game", Address = 0x800659D4u)] public static void Q_800659D4(CpuContext c, IMemory m) => Leave(0x800659D4u, c, m);
    [PreHook("game", Address = 0x8006F378u)] public static void P_8006F378(CpuContext c, IMemory m) => Enter(0x8006F378u, m);
    [PostHook("game", Address = 0x8006F378u)] public static void Q_8006F378(CpuContext c, IMemory m) => Leave(0x8006F378u, c, m);
    [PreHook("game", Address = 0x80071788u)] public static void P_80071788(CpuContext c, IMemory m) => Enter(0x80071788u, m);
    [PostHook("game", Address = 0x80071788u)] public static void Q_80071788(CpuContext c, IMemory m) => Leave(0x80071788u, c, m);
    [PreHook("game", Address = 0x80077808u)] public static void P_80077808(CpuContext c, IMemory m) => Enter(0x80077808u, m);
    [PostHook("game", Address = 0x80077808u)] public static void Q_80077808(CpuContext c, IMemory m) => Leave(0x80077808u, c, m);
    [PreHook("game", Address = 0x80077984u)] public static void P_80077984(CpuContext c, IMemory m) => Enter(0x80077984u, m);
    [PostHook("game", Address = 0x80077984u)] public static void Q_80077984(CpuContext c, IMemory m) => Leave(0x80077984u, c, m);
    [PreHook("game", Address = 0x80077AC4u)] public static void P_80077AC4(CpuContext c, IMemory m) => Enter(0x80077AC4u, m);
    [PostHook("game", Address = 0x80077AC4u)] public static void Q_80077AC4(CpuContext c, IMemory m) => Leave(0x80077AC4u, c, m);
    [PreHook("game", Address = 0x80077C44u)] public static void P_80077C44(CpuContext c, IMemory m) => Enter(0x80077C44u, m);
    [PostHook("game", Address = 0x80077C44u)] public static void Q_80077C44(CpuContext c, IMemory m) => Leave(0x80077C44u, c, m);
    [PreHook("game", Address = 0x80077ED4u)] public static void P_80077ED4(CpuContext c, IMemory m) => Enter(0x80077ED4u, m);
    [PostHook("game", Address = 0x80077ED4u)] public static void Q_80077ED4(CpuContext c, IMemory m) => Leave(0x80077ED4u, c, m);
    [PreHook("game", Address = 0x80078CF4u)] public static void P_80078CF4(CpuContext c, IMemory m) => Enter(0x80078CF4u, m);
    [PostHook("game", Address = 0x80078CF4u)] public static void Q_80078CF4(CpuContext c, IMemory m) => Leave(0x80078CF4u, c, m);
    [PreHook("game", Address = 0x80078ECCu)] public static void P_80078ECC(CpuContext c, IMemory m) => Enter(0x80078ECCu, m);
    [PostHook("game", Address = 0x80078ECCu)] public static void Q_80078ECC(CpuContext c, IMemory m) => Leave(0x80078ECCu, c, m);
    [PreHook("game", Address = 0x8008D05Cu)] public static void P_8008D05C(CpuContext c, IMemory m) => Enter(0x8008D05Cu, m);
    [PostHook("game", Address = 0x8008D05Cu)] public static void Q_8008D05C(CpuContext c, IMemory m) => Leave(0x8008D05Cu, c, m);
    [PreHook("game", Address = 0x8008DED4u)] public static void P_8008DED4(CpuContext c, IMemory m) => Enter(0x8008DED4u, m);
    [PostHook("game", Address = 0x8008DED4u)] public static void Q_8008DED4(CpuContext c, IMemory m) => Leave(0x8008DED4u, c, m);
    [PreHook("game", Address = 0x80094068u)] public static void P_80094068(CpuContext c, IMemory m) => Enter(0x80094068u, m);
    [PostHook("game", Address = 0x80094068u)] public static void Q_80094068(CpuContext c, IMemory m) => Leave(0x80094068u, c, m);
    [PreHook("game", Address = 0x8009BCE0u)] public static void P_8009BCE0(CpuContext c, IMemory m) => Enter(0x8009BCE0u, m);
    [PostHook("game", Address = 0x8009BCE0u)] public static void Q_8009BCE0(CpuContext c, IMemory m) => Leave(0x8009BCE0u, c, m);
    [PreHook("game", Address = 0x800B5A44u)] public static void P_800B5A44(CpuContext c, IMemory m) => Enter(0x800B5A44u, m);
    [PostHook("game", Address = 0x800B5A44u)] public static void Q_800B5A44(CpuContext c, IMemory m) => Leave(0x800B5A44u, c, m);
    [PreHook("game", Address = 0x800B5E20u)] public static void P_800B5E20(CpuContext c, IMemory m) => Enter(0x800B5E20u, m);
    [PostHook("game", Address = 0x800B5E20u)] public static void Q_800B5E20(CpuContext c, IMemory m) => Leave(0x800B5E20u, c, m);
    [PreHook("game", Address = 0x800B62B4u)] public static void P_800B62B4(CpuContext c, IMemory m) => Enter(0x800B62B4u, m);
    [PostHook("game", Address = 0x800B62B4u)] public static void Q_800B62B4(CpuContext c, IMemory m) => Leave(0x800B62B4u, c, m);
    [PreHook("game", Address = 0x800B67A0u)] public static void P_800B67A0(CpuContext c, IMemory m) => Enter(0x800B67A0u, m);
    [PostHook("game", Address = 0x800B67A0u)] public static void Q_800B67A0(CpuContext c, IMemory m) => Leave(0x800B67A0u, c, m);
    [PreHook("game", Address = 0x800B7738u)] public static void P_800B7738(CpuContext c, IMemory m) => Enter(0x800B7738u, m);
    [PostHook("game", Address = 0x800B7738u)] public static void Q_800B7738(CpuContext c, IMemory m) => Leave(0x800B7738u, c, m);
    [PreHook("game", Address = 0x800B7A80u)] public static void P_800B7A80(CpuContext c, IMemory m) => Enter(0x800B7A80u, m);
    [PostHook("game", Address = 0x800B7A80u)] public static void Q_800B7A80(CpuContext c, IMemory m) => Leave(0x800B7A80u, c, m);
    [PreHook("game", Address = 0x800B7E38u)] public static void P_800B7E38(CpuContext c, IMemory m) => Enter(0x800B7E38u, m);
    [PostHook("game", Address = 0x800B7E38u)] public static void Q_800B7E38(CpuContext c, IMemory m) => Leave(0x800B7E38u, c, m);
    [PreHook("game", Address = 0x800B8304u)] public static void P_800B8304(CpuContext c, IMemory m) => Enter(0x800B8304u, m);
    [PostHook("game", Address = 0x800B8304u)] public static void Q_800B8304(CpuContext c, IMemory m) => Leave(0x800B8304u, c, m);
    [PreHook("game", Address = 0x800B8A24u)] public static void P_800B8A24(CpuContext c, IMemory m) => Enter(0x800B8A24u, m);
    [PostHook("game", Address = 0x800B8A24u)] public static void Q_800B8A24(CpuContext c, IMemory m) => Leave(0x800B8A24u, c, m);
    [PreHook("game", Address = 0x800B90E8u)] public static void P_800B90E8(CpuContext c, IMemory m) => Enter(0x800B90E8u, m);
    [PostHook("game", Address = 0x800B90E8u)] public static void Q_800B90E8(CpuContext c, IMemory m) => Leave(0x800B90E8u, c, m);
}
