<!--
  Correzione dissolvenza - README
  Author: https://github.com/Leproide
  License: GPL-3.0-or-later
-->

# Correzione dissolvenza widescreen (prova)

La dissolvenza circolare del gioco copre solo lo schermo 4:3: in widescreen restano scoperti gli angoli (issue #7 del progetto originale). La mod allarga in orizzontale il bordo esterno della dissolvenza in proporzione al margine widescreen. Solo MediEvil PAL italiano.

## Licenza

GPL-3.0-or-later.

## Autore

https://github.com/Leproide
