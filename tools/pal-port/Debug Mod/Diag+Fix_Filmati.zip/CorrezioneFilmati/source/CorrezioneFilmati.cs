// SPDX-License-Identifier: GPL-3.0-or-later
//
// Correzione filmati - mod di prova per MediEvilRecomp ITA
// Copyright (C) 2026
// Author: https://github.com/Leproide
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.

// Perche' i filmati vengono saltati (issue #5 di MediEvilRecomp):
//
// Il lettore dei filmati del gioco (func_80079D90 nella versione PAL) chiede il
// fotogramma successivo con StGetNext in un ciclo di attesa attiva. Se dopo
// 0x400000 (~4 milioni) tentativi non arriva niente, considera il filmato finito.
// Su PlayStation quei tentativi durano alcuni secondi; ricompilati in C# su un PC
// moderno durano una frazione di secondo, mentre RecompOne consegna i fotogrammi
// a velocita' reale (thread di streaming a 150 settori/s). Basta un piccolo
// ritardo del thread e il gioco crede che il filmato sia terminato. Piu' il
// processore e' veloce, piu' succede.
//
// Correzione: stessa logica dell'originale, ma il limite di attesa e' misurato in
// tempo reale (2 secondi) invece che in numero di tentativi.

using System;
using System.Diagnostics;
using System.Threading;
using ImGuiNET;
using RecompOne.Runtime.Context;
using RecompOne.Runtime.Memory;
using RecompOne.Runtime.Modding;

public class CorrezioneFilmatiMod : IMod
{
    const uint PlayerState = 0x800F19B0u;      // struttura del lettore filmati (PAL)
    const uint EndFlag = PlayerState + 0x40u;  // 1 = filmato finito
    const int TimeoutMs = 2000;

    static int _timeouts, _frames;

    public void OnLoad() { }
    public void OnUnload() { }

    public void DrawSettings()
    {
        ImGui.TextWrapped("Attesa dei fotogrammi dei filmati misurata in tempo reale.");
        ImGui.TextDisabled($"Fotogrammi letti: {_frames}  Attese scadute: {_timeouts}");
    }

    // Sostituisce func_80079D90: restituisce in v0 il puntatore ai dati del
    // fotogramma, oppure 0 e segna il filmato come finito.
    [Replace("game", Address = 0x80079D90u)]
    public static void NextFrame(CpuContext c, IMemory m)
    {
        // stesse posizioni sullo stack usate dal codice originale (sp-0x28+0x10/0x14)
        uint pData = c.SP - 0x28u + 0x10u;
        uint pHdr = c.SP - 0x28u + 0x14u;
        uint a0 = c.A0, a1 = c.A1;

        var clock = Stopwatch.StartNew();
        while (true)
        {
            c.A0 = pData;
            c.A1 = pHdr;
            RecompOne.Runtime.Sdk.LibCdStream.StGetNext(c, m);
            if (c.V0 == 0) break;

            if (clock.ElapsedMilliseconds > TimeoutMs)
            {
                _timeouts++;
                Console.WriteLine($"[CorrezioneFilmati] nessun fotogramma per {TimeoutMs} ms: fine filmato");
                m.WriteU32(EndFlag, 1);
                c.A0 = a0; c.A1 = a1;
                c.V0 = 0;
                return;
            }

            // mentre aspetta lascia girare interrupt e callback, come farebbe la console
            RecompOne.Runtime.Interrupts.PollNow(c, m);
            Thread.Sleep(0);
        }

        _frames++;
        uint gp = c.GP;
        uint hdr = m.ReadU32(pHdr);
        uint info = m.ReadU32(gp + 0x764u);
        uint prev = m.ReadU32(gp + 0x760u);
        uint frame = m.ReadU32(hdr + 8u);
        uint frameCount = m.ReadU16(info + 0xCu);

        m.WriteU32(gp + 0x768u, prev);
        m.WriteU32(gp + 0x760u, frame);

        // numero di fotogramma oltre la fine, o tornato indietro: filmato finito
        if (frame >= frameCount || frame < prev) m.WriteU32(EndFlag, 1);
        // dimensioni del fotogramma diverse da quelle attese: filmato finito
        if (m.ReadU32(hdr + 0x10u) != m.ReadU32(info + 8u)) m.WriteU32(EndFlag, 1);

        c.V0 = m.ReadU32(pData);
    }
}
