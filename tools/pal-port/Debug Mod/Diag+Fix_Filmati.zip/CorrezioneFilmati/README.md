<!--
  Correzione filmati - README
  Author: https://github.com/Leproide
  License: GPL-3.0-or-later
-->

# Correzione filmati (prova)

Evita che i filmati pre-renderizzati vengano saltati dopo un secondo o due (issue #5 del progetto originale).
Il lettore dei filmati considera finito il filmato se non riceve un fotogramma entro circa 4 milioni di tentativi:
ricompilati su PC quei tentativi durano una frazione di secondo. La mod misura l'attesa in tempo reale (2 secondi).

Solo MediEvil PAL italiano (SCES-01494).

## Licenza

GPL-3.0-or-later.

## Autore

https://github.com/Leproide
