<!--
  DiagMappa - README
  Author: https://github.com/Leproide
  License: GPL-3.0-or-later
-->

# Diagnostica mappa (temporanea)

Mod di sola lettura per trovare il bug della mappa che si ripete dopo la Sala degli Eroi.
Registra le chiamate alle funzioni della mappa (`landmap`) e del lettore musicale XA, più lo stato
delle variabili della musica, nel file `diag-mappa.txt` della cartella del gioco (massimo 4000 righe).

Non modifica nulla nel gioco. Da cancellare dopo l'uso.

## Licenza

GPL-3.0-or-later.

## Autore

https://github.com/Leproide
