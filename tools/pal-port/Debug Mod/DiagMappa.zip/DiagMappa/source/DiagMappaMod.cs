// SPDX-License-Identifier: GPL-3.0-or-later
//
// DiagMappa - mod diagnostica per MediEvilRecomp ITA
// Copyright (C) 2026
// Author: https://github.com/Leproide
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.

// Diagnostica + correzione di prova, versione 0.4.
//
// Problema 1: lo StUnSetRing HLE di RecompOne non azzera i callback del CD come fa
//   quello originale (CdDataCallback(0) + CdReadyCallback(0)). Dopo i filmati resta
//   installato StCdInterrupt e la mappa va a 1 fotogramma al secondo.
// Problema 2: il gestore della musica XA del gioco (0x80065D20..0x80065FC0) scrive i
//   callback direttamente nelle variabili di libcd (0x800EB660 sync, 0x800EB664 ready)
//   invece di chiamare CdSyncCallback/CdReadyCallback. L'HLE tiene i callback in C# e non
//   le vede, quindi la macchina a stati resta ferma e il caricamento del livello si blocca.
// Correzione: sincronizza in entrambe le direzioni le variabili del gioco e quelle dell'HLE.

using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Text;
using ImGuiNET;
using RecompOne.Runtime.Context;
using RecompOne.Runtime.Memory;
using RecompOne.Runtime.Modding;

public class DiagMappaMod : IMod
{
    const uint SlotSync = 0x800EB660u;    // CD_cbsync della copia di libcd nell'overlay "game" (PAL)
    const uint SlotReady = 0x800EB664u;   // CD_cbready
    const uint EmulateFlag = 0x800EB680u; // StUnSetRing originale: se vale 1 non tocca i callback
    const uint MusicState = 0x800EDA14u;

    static readonly object Gate = new();
    static readonly Stopwatch Clock = Stopwatch.StartNew();
    static long _lastDump;
    static StreamWriter? _out;
    static int _lines;
    const int MaxLines = 3000;
    public static bool Fix = true;

    static readonly FieldInfo? CbReady, CbData, CbSync, ReadActive;

    static DiagMappaMod()
    {
        var t = typeof(IMemory).Assembly.GetType("RecompOne.Runtime.Sdk.LibCd");
        const BindingFlags F = BindingFlags.Static | BindingFlags.NonPublic | BindingFlags.Public;
        CbReady = t?.GetField("_cbReady", F);
        CbData = t?.GetField("_cbData", F);
        CbSync = t?.GetField("_cbSync", F);
        ReadActive = t?.GetField("_readActive", F);
    }

    static uint Get(FieldInfo? f) { try { return f?.GetValue(null) is uint v ? v : 0xDEADu; } catch { return 0xDEADu; } }
    static void Set(FieldInfo? f, uint v) { try { f?.SetValue(null, v); } catch { } }
    static string GetB(FieldInfo? f) { try { return f?.GetValue(null)?.ToString() ?? "?"; } catch { return "?"; } }

    public void OnLoad()
    {
        try
        {
            var path = Path.GetFullPath("diag-mappa.txt");
            _out = new StreamWriter(path, false, new UTF8Encoding(false)) { AutoFlush = true };
            Write($"[DiagMappa 0.4] log in {path} | campi trovati: ready={CbReady != null} data={CbData != null} sync={CbSync != null}");
        }
        catch (Exception e) { Console.WriteLine($"[DiagMappa] impossibile creare il file: {e.Message}"); }
    }

    public void OnUnload()
    {
        lock (Gate) { _out?.Dispose(); _out = null; }
    }

    public void DrawSettings()
    {
        ImGui.Checkbox("Correzione callback CD (prova)", ref Fix);
        ImGui.TextWrapped("Scrive diag-mappa.txt nella cartella del gioco.");
        ImGui.TextDisabled($"Righe scritte: {_lines}/{MaxLines}");
    }

    static void Write(string s)
    {
        lock (Gate)
        {
            if (_lines >= MaxLines) return;
            _lines++;
            Console.WriteLine(s);
            _out?.WriteLine(s);
        }
    }

    static string T => (Clock.ElapsedMilliseconds / 1000.0).ToString("0.000");

    static string State(IMemory m) =>
        $"HLE ready={Get(CbReady):X8} sync={Get(CbSync):X8} data={Get(CbData):X8} readActive={GetB(ReadActive)} | " +
        $"gioco ready={m.ReadU32(SlotReady):X8} sync={m.ReadU32(SlotSync):X8} musica={m.ReadU32(MusicState):X}";

    // Il gioco ha scritto le variabili di libcd: le copio nell'HLE.
    static void SyncFromMemory(IMemory m, string who)
    {
        var ready = m.ReadU32(SlotReady);
        var sync = m.ReadU32(SlotSync);
        if (Fix)
        {
            Set(CbReady, ready);
            Set(CbSync, sync);
        }
        Write($"{T} macchina XA {who}: {State(m)}");
    }

    // Il gioco ha usato CdSyncCallback/CdReadyCallback (HLE): aggiorno le sue variabili.
    static void SyncToMemory(IMemory m, string who)
    {
        if (!Fix) return;
        m.WriteU32(SlotReady, Get(CbReady));
        m.WriteU32(SlotSync, Get(CbSync));
    }

    static void AfterStUnSetRing(IMemory m, bool gameCopy)
    {
        if (!Fix) return;
        if (gameCopy && m.ReadU32(EmulateFlag) == 1) return;
        Set(CbData, 0);
        Set(CbReady, 0);
        if (gameCopy) m.WriteU32(SlotReady, 0);
        Write($"{T} StUnSetRing ({(gameCopy ? "game" : "main")}): callback data/ready azzerati");
    }

    static void Tick(IMemory m)
    {
        var t = Clock.ElapsedMilliseconds;
        if (t - _lastDump < 1000) return;
        _lastDump = t;
        Write($"{T} STATO: {State(m)}");
    }

    [PostHook("game", Address = 0x80065D20u)] public static void S_80065D20(CpuContext c, IMemory m) => SyncFromMemory(m, "80065D20");
    [PostHook("game", Address = 0x80065D54u)] public static void S_80065D54(CpuContext c, IMemory m) => SyncFromMemory(m, "80065D54");
    [PostHook("game", Address = 0x80065D88u)] public static void S_80065D88(CpuContext c, IMemory m) => SyncFromMemory(m, "80065D88");
    [PostHook("game", Address = 0x80065DC0u)] public static void S_80065DC0(CpuContext c, IMemory m) => SyncFromMemory(m, "80065DC0");
    [PostHook("game", Address = 0x80065E0Cu)] public static void S_80065E0C(CpuContext c, IMemory m) => SyncFromMemory(m, "80065E0C");
    [PostHook("game", Address = 0x80065E8Cu)] public static void S_80065E8C(CpuContext c, IMemory m) => SyncFromMemory(m, "80065E8C");
    [PostHook("game", Address = 0x80065F8Cu)] public static void S_80065F8C(CpuContext c, IMemory m) => SyncFromMemory(m, "80065F8C");
    [PostHook("game", Address = 0x800AB0FCu)] public static void G_CdSyncCallback(CpuContext c, IMemory m) => SyncToMemory(m, "CdSyncCallback");
    [PostHook("game", Address = 0x800AB110u)] public static void G_CdReadyCallback(CpuContext c, IMemory m) => SyncToMemory(m, "CdReadyCallback");
    [PostHook("game", Address = 0x800B2284u)] public static void G_StUnSetRing(CpuContext c, IMemory m) => AfterStUnSetRing(m, true);
    [PostHook("main", Address = 0x801BBF70u)] public static void M_StUnSetRing(CpuContext c, IMemory m) => AfterStUnSetRing(m, false);
    [PostHook("game", Address = 0x800A3E18u)] public static void G_VSync(CpuContext c, IMemory m) => Tick(m);
}
